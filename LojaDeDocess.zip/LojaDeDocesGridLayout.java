import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LojaDeDocesGridLayout extends JFrame implements ActionListener {

    private JTextField txtQtdBrigadeiro, txtQtdCookies, txtQtdPudim;
    private JButton btnPedir;
    private double precoBrigadeiro = 10.0;
    private double precoCookies = 15.0;
    private double precoPudim = 25.0;

    public LojaDeDocesGridLayout() {
        super("Loja de Doces");
        setLayout(new GridLayout(4, 3, 10, 10));

        // Brigadeiro
        ImageIcon imgBrigadeiro = redimensionarImagem("C:\\Users\\Aluno\\Documents\\tarefas java\\imagens\\brigadeiro.png", 200, 200);
        JButton btnBrigadeiro = new JButton(imgBrigadeiro);
        btnBrigadeiro.addActionListener(e -> adicionarUm(txtQtdBrigadeiro));

        JLabel lblPrecoBrigadeiro = new JLabel("R$ " + precoBrigadeiro + "0");
        txtQtdBrigadeiro = new JTextField("0", 5);

        // Cookies
        ImageIcon imgCookies = redimensionarImagem("C:\\Users\\Aluno\\Documents\\tarefas java\\imagens\\cookies.png", 100, 100);
        JButton btnCookies = new JButton(imgCookies);
        btnCookies.addActionListener(e -> adicionarUm(txtQtdCookies));

        JLabel lblPrecoCookies = new JLabel("R$ " + precoCookies + "0");
        txtQtdCookies = new JTextField("0", 5);

        // Pudim
        ImageIcon imgPudim = redimensionarImagem("C:\\Users\\Aluno\\Documents\\tarefas java\\imagens\\pudim.png", 100, 100);
        JButton btnPudim = new JButton(imgPudim);
        btnPudim.addActionListener(e -> adicionarUm(txtQtdPudim));

        JLabel lblPrecoPudim = new JLabel("R$ " + precoPudim + "0");
        txtQtdPudim = new JTextField("0", 5);

        // Adicionando componentes no GridLayout
        add(btnBrigadeiro);
        add(lblPrecoBrigadeiro);
        add(txtQtdBrigadeiro);

        add(btnCookies);
        add(lblPrecoCookies);
        add(txtQtdCookies);

        add(btnPudim);
        add(lblPrecoPudim);
        add(txtQtdPudim);

        add(new JLabel(""));
        btnPedir = new JButton("Pedir");
        btnPedir.addActionListener(this);
        add(btnPedir);
        add(new JLabel(""));

        setSize(500, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // Redimensiona imagem
    private ImageIcon redimensionarImagem(String caminho, int largura, int altura) {
        ImageIcon icon = new ImageIcon(caminho);
        Image img = icon.getImage().getScaledInstance(largura, altura, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }

    private void adicionarUm(JTextField txt) {
        int qtd = Integer.parseInt(txt.getText());
        txt.setText(Integer.toString(qtd + 1));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int qtdBrigadeiro = Integer.parseInt(txtQtdBrigadeiro.getText());
        int qtdCookies = Integer.parseInt(txtQtdCookies.getText());
        int qtdPudim = Integer.parseInt(txtQtdPudim.getText());

        double total = (qtdBrigadeiro * precoBrigadeiro)
                      + (qtdCookies * precoCookies)
                      + (qtdPudim * precoPudim);

        JOptionPane.showMessageDialog(this,
                "O total da compra: R$ " + total,
                "Sistema de doces",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LojaDeDocesGridLayout());
    }
}
